package com.utils;

public class Constants {
    public final static String CALLER_PREF_KEY = "CALLER_LIST";
    public final static String APP_NAME_PREF_KEY = "APP_NAME";

}
